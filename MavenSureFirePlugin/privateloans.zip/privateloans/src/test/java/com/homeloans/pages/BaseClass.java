package com.homeloans.pages;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	protected static WebDriver driver = null;
	@BeforeSuite
	public void setup() {
		System.out.println("Before suite");
		WebDriverManager.chromedriver().setup();
		
	}
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}

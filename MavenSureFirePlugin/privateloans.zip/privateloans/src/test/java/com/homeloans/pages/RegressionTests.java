package com.homeloans.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class RegressionTests extends BaseClass{
	
	@BeforeMethod
	public void setup() {
		System.out.println("Before Method");
		driver = new ChromeDriver();
	}
	@Test
	public void googleSearch() throws InterruptedException {
		driver.get("http://www.google.co.in");
		WebElement txtSearch;
		txtSearch = driver.findElement(By.xpath("//input[@name='q']"));
		txtSearch.sendKeys("Latest Samsung mobile phones" + Keys.ENTER);
		Thread.sleep(4000);
		Assert.assertTrue(driver.getTitle().contains("Samsung"));
	}
	@AfterMethod
	public void tearDown() {
		driver.close();
	}
	@Test
	public void wikiSearch() throws InterruptedException {
		driver.get("https://en.wikipedia.org/wiki/Main_Page");
		Thread.sleep(3000);
	}

}

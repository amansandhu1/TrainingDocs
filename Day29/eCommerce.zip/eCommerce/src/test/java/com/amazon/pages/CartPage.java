package com.amazon.pages;

public class CartPage {

}

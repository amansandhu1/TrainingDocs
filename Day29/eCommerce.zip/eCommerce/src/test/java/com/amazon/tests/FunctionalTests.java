package com.amazon.tests;

import org.openqa.selenium.Keys;

import com.amazon.framework.BaseClass;
import com.amazon.pages.HomePage;

public class FunctionalTests extends BaseClass {

	public static void main(String[] args) throws InterruptedException {
		Initialize();
		LaunchApp("https://www.amazon.in");

		HomePage h1 = new HomePage(driver);
		h1.performSearch("Samsung new mobile phones" + Keys.ENTER);

		Thread.sleep(10000);

		CloseApp();

	}

}

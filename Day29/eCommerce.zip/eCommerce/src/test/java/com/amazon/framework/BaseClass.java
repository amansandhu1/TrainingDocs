package com.amazon.framework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	protected static WebDriver driver;
	
	public static void Initialize(){
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}
	public static void LaunchApp(String url) {
		driver.get(url);
	}
	public static void CloseApp() {
		driver.close();
		driver.quit();
	}
	
	

}
